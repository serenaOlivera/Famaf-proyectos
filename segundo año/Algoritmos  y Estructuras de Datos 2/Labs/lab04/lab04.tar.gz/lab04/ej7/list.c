/*First including the libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "list.h"

/*Second defininig the struct*/
struct node_of_T{
    list_elem elem;
    struct node_of_T *next;
};

/*Now, implementing*/

list empty(){
    list l = NULL;
    return l;
}

list add_l (list_elem e, list l){
    list p = malloc(sizeof(struct node_of_T));
    p->elem = e;
    p->next = l;
    l = p;

    return l;
}

list destroy (list l){
    free(l);
    return NULL;
}

bool is_empty(list l){
    if (l == NULL){
        return true;
    }else{
        return false;
    }
}

list_elem head (list l){
    assert (!is_empty(l));
    return l->elem;
}

list tail (list l){
    assert(!is_empty(l));
    list p = malloc (sizeof(struct node_of_T));
    p = l->next;
    l = p;
    return l;
    free(p);
}

list addr (list_elem e, list l){
    list p = malloc (sizeof(struct node_of_T));
    p->elem = e;
    p ->next = NULL;
    if (!is_empty(l)){
        list q = l;
        while (q->next != NULL){
            q = q->next;
        }
        q->next = p;
    }else{
        l=p;
    }

    return l;
}

unsigned int length (list l){
    unsigned int counter = 0;
    list p = l;
    while (!is_empty(p)){
        p = p->next;
        counter++;
    }
    return counter;
}

list concat (list l, list l0){
    list p = malloc(sizeof(struct node_of_T));
    p = l;
    if (l == NULL && l0 == NULL){
        return NULL;
    }
    if (l==NULL){
        return l0;
    }
    else if (l0 == NULL){
        return l;
    }else{
        while (p->next!=NULL){
            p = p->next;
        }
        p->next = l0;
    }
    return p;
}

list_elem index (list l, unsigned int n){
    assert(length(l)>n);
    list p = l;
    if (n < 1){
        return p->elem;
    }else{
        for (unsigned int i = 0; i < n; i++)
        {
            p = p->next;
        }     
    }
    return p->elem;
}

list take (list l, unsigned int n){
    list p = NULL;
    list q = NULL;
    p = l;
    unsigned int i = 0;
    if(n == 0) {
        while(l != NULL) {
            p = l;
            l = l->next;
            free(p);
        }
    }
    else {
        while(l != NULL && i < n) {
            p = p->next;
            i++;
        }
        
        while(p != NULL) {
            q = p;
            p = p->next;
            free(q);
        }
    }
    return l;
}


list drop(list l, unsigned int n) {
    list p = NULL;
    unsigned int i = 0;
    if(l != NULL && 0 < n) {
        while(l != NULL && i < n) {
            p = l;
            l = l->next;
            free(p);
            i++;
        }
    }
    return l;
}

list copy_list(list l) {
    list copy = empty();
    list p = l;
    while(p != NULL) {
		copy = addr(p->elem, copy);
		p = p->next;
	}
	return(copy);
}